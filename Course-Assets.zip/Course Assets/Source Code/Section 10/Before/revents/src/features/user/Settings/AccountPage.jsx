import React from 'react'

const AccountPage = () => {
  return (
    <div>
      <h1>Account Page</h1>
    </div>
  )
}

export default AccountPage
