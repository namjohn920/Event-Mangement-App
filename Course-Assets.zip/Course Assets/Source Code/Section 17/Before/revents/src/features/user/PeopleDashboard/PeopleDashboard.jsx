import React from 'react'

const PeopleDashboard = () => {
  return (
    <div>
      <h1>People Dashboard</h1>
    </div>
  )
}

export default PeopleDashboard
