import React from 'react'

const PhotosPage = () => {
  return (
    <div>
      <h1>Photos page</h1>
    </div>
  )
}

export default PhotosPage
