import React from 'react'

const UserDetailedPage = () => {
  return (
    <div>
      <h1>User detailed page</h1>
    </div>
  )
}

export default UserDetailedPage
